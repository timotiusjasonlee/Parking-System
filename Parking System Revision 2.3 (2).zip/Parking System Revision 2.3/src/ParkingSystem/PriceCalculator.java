package ParkingSystem;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
abstract public class PriceCalculator {
	
	protected long biayaParkir,biayaAkhir;
	protected String stringBiayaParkir="", stringBiayaAkhir="",stringTotalAccumulate="";
	public String getStringTotalAccumulate() {
		return stringTotalAccumulate;
	}

	public void setStringTotalAccumulate(String stringTotalAccumulate) {
		this.stringTotalAccumulate = stringTotalAccumulate;
	}

	public String getStringBiayaParkir() {
		return stringBiayaParkir;
	}

	public void setStringBiayaParkir(String stringBiayaParkir) {
		this.stringBiayaParkir = stringBiayaParkir;
	}

	public String getStringBiayaAkhir() {
		return stringBiayaAkhir;
	}

	public void setStringBiayaAkhir(String stringBiayaAkhir) {
		this.stringBiayaAkhir = stringBiayaAkhir;
	}

	public long getBiayaParkir() {
		return biayaParkir;
	}

	public void setBiayaParkir(long biayaParkir) {
		this.biayaParkir = biayaParkir;
	}

	public long getBiayaAkhir() {
		return biayaAkhir;
	}

	public void setBiayaAkhir(long biayaAkhir) {
		this.biayaAkhir = biayaAkhir;
	}


	protected long Days = MenuUtama.calculateDate.getTotalDays();
	protected long Hours = MenuUtama.calculateDate.getTotalHours();
	protected long Minutes = MenuUtama.calculateDate.getTotalMinutes();
	
		
	public void currencyConverter(long biayaparkir, long biayaakhir) {
		DecimalFormat rupiah = (DecimalFormat) DecimalFormat.getCurrencyInstance();
		DecimalFormatSymbols formatRupiah = new DecimalFormatSymbols();
		formatRupiah.setCurrencySymbol("Rp. ");
		formatRupiah.setMonetaryDecimalSeparator(',');
		formatRupiah.setGroupingSeparator('.');
		
		rupiah.setDecimalFormatSymbols(formatRupiah);
		
		setStringBiayaAkhir(rupiah.format(biayaakhir));
		setStringBiayaParkir(rupiah.format(biayaparkir));
	}
	public void currencyConvert2(long totalAccumulate) {
		DecimalFormat rupiah = (DecimalFormat) DecimalFormat.getCurrencyInstance();
		DecimalFormatSymbols formatRupiah = new DecimalFormatSymbols();
		formatRupiah.setCurrencySymbol("Rp. ");
		formatRupiah.setMonetaryDecimalSeparator(',');
		formatRupiah.setGroupingSeparator('.');
		
		rupiah.setDecimalFormatSymbols(formatRupiah);
		
		setStringTotalAccumulate(rupiah.format(totalAccumulate));
	}
	
	abstract void getPrice();
	
	
}
