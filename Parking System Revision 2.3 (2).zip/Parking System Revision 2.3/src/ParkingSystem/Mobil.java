package ParkingSystem;


public class Mobil extends Kendaraan {

	public Mobil() {
		// TODO Auto-generated constructor stub
	}

}
