package ParkingSystem;


public class Kendaraan {
	public String platNomor="",jenisKendaraan="",tanggalMasuk="",jamMasuk="";
	public int noTicket=0,durasi=0;
	public String biayaParkir="",biayaAkhir="";
	
	public String getBiayaParkir() {
		return biayaParkir;
	}
	public void setBiayaParkir(String biayaParkir) {
		this.biayaParkir = biayaParkir;
	}
	public String getBiayaAkhir() {
		return biayaAkhir;
	}
	public void setBiayaAkhir(String biayaAkhir) {
		this.biayaAkhir = biayaAkhir;
	}
	public String getPlatNomor() {

		return platNomor;
	}
	public void setPlatNomor(String platNomor) {
		this.platNomor = platNomor;
	}
	public String getJenisKendaraan() {
		return jenisKendaraan;
	}
	public void setJenisKendaraan(String jenisKendaraan) {
		this.jenisKendaraan = jenisKendaraan;
	}
	public String getTanggalMasuk() {
		return tanggalMasuk;
	}
	public void setTanggalMasuk(String tanggalMasuk) {
		this.tanggalMasuk = tanggalMasuk;
	}
	public String getJamMasuk() {
		return jamMasuk;
	}
	public void setJamMasuk(String jamMasuk) {
		this.jamMasuk = jamMasuk;
	}
	public int getNoTicket() {
		return noTicket;
	}
	public void setNoTicket(int noTicket) {
		this.noTicket = noTicket;
	}
	public int getDurasi() {
		return durasi;
	}
	public void setDurasi(int durasi) {

		this.durasi = durasi;
		
	}
	
	
	
	
}
