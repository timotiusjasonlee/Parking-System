package ParkingSystem;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Main.Main;
public class MenuUtama implements Logo{
	
	public static long totalIncome;
	public static DateCalculator calculateDate;
	public static String totalAcumulate;
	void clr() {
		for(int i=0;i < 40;i++) {
			System.out.println();
		}
	}
	
	public boolean stringContaintsNumber(String license) {
		Pattern pattern = Pattern.compile("[0-9]");
		Matcher matcher = pattern.matcher(license);
		
		return matcher.find();
	}
	
	public boolean stringContaintsChar(String license) {

		Pattern pattern = Pattern.compile("[A-Z]");
		Matcher matcher = pattern.matcher(license);
	
		return matcher.find();
	}
	
	public MenuUtama() {
		
		boolean resetPol = false; 
		int menuPilihan = 1;

		String noPolisi="",jenisKendaraan="",pilihan="";
		
		display();
		do {
			System.out.println("===============");
			System.out.println("Parking Machine");
			System.out.println("===============");
			System.out.println("1. Parkir Masuk");
			System.out.println("2. Parkir Keluar");
			System.out.println("3. Logout");
			System.out.print("Pilihan >> ");
			try {
				menuPilihan = Main.in.nextInt();
				Main.in.nextLine();
			} catch (Exception e) {
				Main.in.nextLine();
			}	
			
			switch(menuPilihan) {
			case 1:
				boolean resetAll = false;	
				System.out.println();
				
				do {
					resetAll = false;
					
					noPolisi = insertNoPol(noPolisi, resetPol);
					
					System.out.println();
					System.out.println("[--Pilih Jenis Kendaraan--]");
					System.out.println("|          Mobil          |");
					System.out.println("|          Motor          |");
					System.out.println("|         Bus/Truk        |");
					
					do {
						System.out.print("Jenis Kendaraan: ");
						jenisKendaraan = Main.in.nextLine();
					} while (!jenisKendaraan.equalsIgnoreCase("Mobil") && !jenisKendaraan.equalsIgnoreCase("Motor") && !jenisKendaraan.equalsIgnoreCase("Bus") && !jenisKendaraan.equals("Truk"));
					jenisKendaraan = jenisKendaraan.toUpperCase().charAt(0)+jenisKendaraan.substring(1, jenisKendaraan.length());
					
					System.out.println();
					System.out.println(" ________________     _______________");
					System.out.println("|     Simpan     | | |     Reset     |");
					System.out.println(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾     ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
					
					do {
						System.out.print("Pilihan >> ");
						pilihan = Main.in.nextLine();
					} while (!pilihan.equalsIgnoreCase("Simpan") && !pilihan.equalsIgnoreCase("Reset"));
					
					if (pilihan.equalsIgnoreCase("Simpan")) {
						addDataKendaraan(noPolisi, jenisKendaraan);
						descendingSort();
						viewDataKendaraan();
					} else {
						resetAll = true;
						clr();
					} 
				} while (resetAll == true);
				
				Main.in.nextLine();
				clr();
				break;
				
			case 2:
				
				if(Main.dataKendaraan.isEmpty()) {
					System.out.println(" ____________________________________________________________________________________");
					System.out.println("| No.Ticket   | No.Pol          | Jenis Kendaraan    | Tanggal Masuk  | Jam Masuk    |");
					System.out.println("|_____________|_________________|____________________|________________|______________|");
					System.out.println("|                                   DATA KOSONG                                      |");
					System.out.println("|                                                                                    |");
					System.out.println(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
				}
				else {
					viewDataKendaraanPrice();
					viewDataKendaraan();
					boolean loopMenu2 = false;
			
					do {
		
						loopMenu2 = false;
						System.out.println();
						noPolisi = insertNoPol(noPolisi, resetPol);
		
						for (int i = 0; i < Main.dataKendaraan.size(); i++) {
							if (i == Main.dataKendaraan.size() - 1 && !noPolisi.equals(Main.dataKendaraan.get(i).getPlatNomor())) {
								System.out.print(" No Pelat Kendaraan Tidak Terdaftar");
								loopMenu2 = true;
								break;
							}
							
							else if (noPolisi.equals(Main.dataKendaraan.get(i).getPlatNomor())) {
								int noTicket = Main.dataKendaraan.get(i).getNoTicket();
								String jenisKendaraan1 = Main.dataKendaraan.get(i).getJenisKendaraan();
								String dateMasuk = Main.dataKendaraan.get(i).getTanggalMasuk();
								String jamMasuk = Main.dataKendaraan.get(i).getJamMasuk();

								calculateDate = new DateCalculator();
								Kendaraan kendaraan = new Kendaraan();
								calculateDate.calculateDateTime(i);
								
								PriceCalculator calculatePrice;
								if (Main.dataKendaraan.get(i).getJenisKendaraan().equalsIgnoreCase("Mobil")) {
									calculatePrice = new PriceCalculatorMobil();
									calculatePrice.getPrice();
									kendaraan.setBiayaParkir(calculatePrice.getStringBiayaParkir());
									kendaraan.setBiayaAkhir(calculatePrice.getStringBiayaAkhir());
								}
								
								else if(Main.dataKendaraan.get(i).getJenisKendaraan().equalsIgnoreCase("Motor")) {
									calculatePrice = new PriceCalculatorMotor();
									calculatePrice.getPrice();
									kendaraan.setBiayaParkir(calculatePrice.getStringBiayaParkir());
									kendaraan.setBiayaAkhir(calculatePrice.getStringBiayaAkhir());
								}
								
								else {
									calculatePrice = new PriceCalculatorBusnTruck();
									calculatePrice.getPrice();
									kendaraan.setBiayaParkir(calculatePrice.getStringBiayaParkir());
									kendaraan.setBiayaAkhir(calculatePrice.getStringBiayaAkhir());
								}
													
								System.out.println();
								System.out.println(
										"|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|");
								System.out.println(
										"|               _________________________________                                          |");
								System.out.printf(
										"| No. Pol      | %-11s                     |                                         |\n",
										noPolisi);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                                          |");
								System.out.println(
										"|               _________________________________                                          |");
								System.out.printf(
										"| No. Tiket    | %-6d                          |                                         |\n",
										noTicket);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                                          |");
								System.out.println(
										"|               _________________________________                                          |");
								System.out.printf(
										"| Jenis        | %-9s                       |                                         |\n",
										jenisKendaraan1);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                                          |");
								System.out.println(
										"|               __________________________                  ____________________________   |");
								System.out.printf(
										"| Tgl Masuk    | %-10s               |    Jam Masuk   | %-8s                   |  |\n",
										dateMasuk, jamMasuk);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                  ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾   |");
								System.out.println(
										"|               __________________________                  ____________________________   |");
								System.out.printf(
										"| Durasi Hari  | %-3s hari                 |    Durasi Jam  | %-2s jam                     |  |\n",
										calculateDate.getOutputHari(),
										calculateDate.getOutputJam()
										);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                  ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾   |");
								System.out.println(
										"|               __________________________                  ____________________________   |");
								System.out.printf(
										"| Biaya Parkir | %-4s             |    Biaya Akhir | %-15s            |  |\n",
										kendaraan.getBiayaParkir(),
										kendaraan.getBiayaAkhir()
										);
								System.out.println(
										"|               ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾                  ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾   |");
								System.out.println(
										"|__________________________________________________________________________________________|");


								totalIncome += calculatePrice.getBiayaAkhir();
								calculatePrice.currencyConvert2(totalIncome);
								totalAcumulate = calculatePrice.getStringTotalAccumulate();
								Main.dataKendaraan.remove(i);
								break;
							}
							
						} 
						
					} while (loopMenu2 == true);
				}
				Main.in.nextLine();
				clr();
				break;
			}
			
		} while (menuPilihan >=1 && menuPilihan<=2 || menuPilihan < 1 && menuPilihan > 3 || menuPilihan!=3);
		
	}

	public String insertNoPol(String noPolisi, boolean resetPol) {
		do {
			StringBuilder sb = new StringBuilder(11);
			resetPol = false;
			String head="",mid="",tail="";
			System.out.print(" No. Pol [cth. format: DB 1234 AE]: ");

			Main.in.useDelimiter("\\s");
			
			head = Main.in.next().toUpperCase();
			if(head.length() > 2 || head.length()<1) {
				resetPol = true;
			}else {
				mid = Main.in.next().toUpperCase();
				if(mid.length() < 1 || mid.length() > 4) {
					resetPol = true;
				}else {
					tail = Main.in.next().toUpperCase();
					if(tail.length() < 1 || tail.length() > 3) {
						resetPol = true;
					}
				}
				
			}
		if(resetPol!=true) {
			if (stringContaintsNumber(head) == true || stringContaintsChar(mid) == true || stringContaintsNumber(tail) == true) {
				resetPol = true;
			}else {
					sb.append(head).append(" ").append(mid).append(" ").append(tail);
					noPolisi = sb.toString();
				}
		}
			
			Main.in.nextLine();
		} while (resetPol == true);
		
		return noPolisi;
	}

	public void addDataKendaraan(String noPolisi, String jenisKendaraan) {
		Kendaraan kendaraan = new Kendaraan();

		Date date = new Date();
		SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
		SimpleDateFormat formatTime = new SimpleDateFormat("HH:mm:ss");
		String strDate = formatDate.format(date);
		String strTime = formatTime.format(date);
		
		kendaraan.setNoTicket(Main.counterEntrace);
		kendaraan.setPlatNomor(noPolisi);
		kendaraan.setJenisKendaraan(jenisKendaraan);
		kendaraan.setTanggalMasuk(strDate);
		kendaraan.setJamMasuk(strTime);
	
		Main.dataKendaraan.add(kendaraan);
		Main.counterEntrace++;
	}
	
	public void descendingSort() {
		Collections.sort(Main.dataKendaraan, new Comparator<Kendaraan>() {
			
			public int compare(Kendaraan p1, Kendaraan p2) {
				return Integer.valueOf(p2.noTicket).compareTo(p1.noTicket);
			}
			
		});
	}
	
	public void viewDataKendaraan() {
		System.out.println(" __________________________________________________________________________________________");
		System.out.println("| No.Ticket   | No.Pol            | Jenis Kendaraan    | Tanggal Masuk    | Jam Masuk      |");
		System.out.println("|_____________|___________________|____________________|__________________|________________|");
		
		for(int i = 0; i < Main.dataKendaraan.size();i++) {
			System.out.printf("| %-3d         | %-11s       | %-9s          | %-10s       | %-8s       |\n",
					Main.dataKendaraan.get(i).getNoTicket(),
					Main.dataKendaraan.get(i).getPlatNomor(),
					Main.dataKendaraan.get(i).getJenisKendaraan(),
					Main.dataKendaraan.get(i).getTanggalMasuk(),
					Main.dataKendaraan.get(i).getJamMasuk());
			System.out.println("|_____________|___________________|____________________|__________________|________________|");
		}
		
	}

	public void viewDataKendaraanPrice() {
		System.out.println(" __________________________________________________________________________________________");
		System.out.println("|                             |                          Harga                             |");
		System.out.println("|       Jenis Kendaraan       |‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|");
		System.out.println("|                             |    1 Jam Pertama    |   Jam berikutnya    |      Hari      |");
		System.out.println("|_____________________________|_____________________|_____________________|________________|");
		System.out.println("|                             |                     |                     |                |");
		System.out.println("|           Mobil             |      Rp.7.000       |      Rp.4.000       |    Rp.50.000   |");
		System.out.println("|                             |                     |                     |                |");
		System.out.println("|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾|");
		System.out.println("|           Motor             |      Rp.3.000       |      Rp.1.000       |    Rp.15.000   |");
		System.out.println("|_____________________________|_____________________|_____________________|________________|");
		System.out.println("|                             |                     |                     |                |");
		System.out.println("|          Bus/Truk           |      Rp.5.000       |      Rp.2.000       |    Rp.35.000   |");
		System.out.println("|_____________________________|_____________________|_____________________|________________|");
		
	}

	@Override
	public void display() {
		try {
			System.out.println(" _______    _______    ______      __     __    __    ____    __    ________");
			Thread.sleep(250);
			System.out.println("|  __   |  |  __   |  |    _ |    |  |   |  |  |  |__|    |__|  |  |     ___|");
			Thread.sleep(250);
			System.out.println("| |__|  |  | |__|  |  |   | ||    |   |_|  |   |                |  |    |");
			Thread.sleep(250);
			System.out.println("|  _____|  |       |  |   |_||_   |       |    |    __    __    |  |   |____");
			Thread.sleep(250);
			System.out.println("|  |       |  __   |  |    __  |  |    _   |   |   |  |  |  |   |  |    ____| ");
			Thread.sleep(250);
			System.out.println("|  |       |  | |  |  |   |  | |  |   | |  |   |   |  |  |  |   |  |    |___");
			Thread.sleep(250);
			System.out.println("|__|       |__| |__|  |___|  |_|  |__|   |__|  |__|   |__|   |__|  |________|");
			Thread.sleep(250);
			System.out.println("");
			System.out.println("");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		new MenuUtama();
	}

}	
