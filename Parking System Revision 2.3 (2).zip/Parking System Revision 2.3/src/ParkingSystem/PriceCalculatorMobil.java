package ParkingSystem;

public class PriceCalculatorMobil extends PriceCalculator{
	
	@Override
	void getPrice() {
		biayaParkir = 7000;
		if(Days < 1 ) {
			//Jika kurang dari sama dengan 1 jam
			if(Hours <=1 ) {
				biayaAkhir = biayaParkir;
			}
			//Jika lebih dari 1 jam 
			else {
				//Harga 1 jam pertama + Harga untuk jam berikutnya
				biayaAkhir = (7000 + ((Hours - 1) * 4000));
			}
		}
		else {
			//Jika lebih dari sama dengan 1 hari maka dikenakan biaya perhari
			biayaAkhir = 50000 * Days;
		}
		
		setBiayaParkir(biayaParkir);
		setBiayaAkhir(biayaAkhir);
		currencyConverter(biayaParkir, biayaAkhir);
		
	}
	
}
