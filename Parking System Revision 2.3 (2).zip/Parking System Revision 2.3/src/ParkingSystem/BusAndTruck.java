package ParkingSystem;


public class BusAndTruck extends Kendaraan {

	public BusAndTruck() {
		// TODO Auto-generated constructor stub
	}

}
