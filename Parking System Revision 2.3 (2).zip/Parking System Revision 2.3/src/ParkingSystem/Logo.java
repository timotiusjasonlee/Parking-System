package ParkingSystem;

public interface Logo {
	void display();
}
