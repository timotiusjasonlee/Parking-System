package ParkingSystem;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import Main.Main;
public class DateCalculator {

    protected long total=0,totalDays=0,totalHours=0,totalMinutes=0,totalSeconds=0;
	protected String outputHari="",outputJam="";

	public long getTotalDays() {
		return totalDays;
	}
	public void setTotalDays(long totalDays) {
		this.totalDays = totalDays;
	}
	public long getTotalHours() {
		return totalHours;
	}
	public void setTotalHours(long totalHours) {
		this.totalHours = totalHours;
	}
	public long getTotalMinutes() {
		return totalMinutes;
	}
	public void setTotalMinutes(long totalMinutes) {
		this.totalMinutes = totalMinutes;
	}
	public String getOutputHari() {
		return outputHari;
	}
	public void setOutputHari(String outputHari) {
		this.outputHari = outputHari;
	}
	public String getOutputJam() {
		return outputJam;
	}
	public void setOutputJam(String outputJam) {

		this.outputJam = outputJam;
	}
		
	private void formatTimeDifference(int indexData) {
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = new Date();//tambahin
		
		String dateStart = Main.dataKendaraan.get(indexData).getTanggalMasuk()+" "+Main.dataKendaraan.get(indexData).getJamMasuk();
		
		String dateEnd = format.format(date);//ganti
		
		
		Date awal = null;
		Date akhir = null;
		
		try {
			awal = format.parse(dateStart);
			akhir = format.parse(dateEnd);		
			total = akhir.getTime() - awal.getTime();

			totalDays = total / (24 * 60 *60 *1000);
			totalHours = total / (60 * 60 *1000) % 24;
			totalMinutes = total / (60 * 1000) % 60;
			
			setTotalDays(totalDays);
			setTotalHours(totalHours);
			setTotalMinutes(totalMinutes);
			
		} catch (ParseException e) {
			Main.in.nextLine();
		}
	}
	protected void calculateDateTime(int indexData) {
		formatTimeDifference(indexData);
		outputHari = Long.toString(totalDays);
		outputJam = Long.toString(totalHours);
		if(outputHari.equals("0")) {
			if(outputJam.equals("0")) {
				outputJam = "1";
			}
			outputHari = "-";	
		}
		setOutputHari(outputHari);
		setOutputJam(outputJam);
	}
}
