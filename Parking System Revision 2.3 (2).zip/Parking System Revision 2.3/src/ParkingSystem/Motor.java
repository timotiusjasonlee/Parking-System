package ParkingSystem;


public class Motor extends Kendaraan {

	public Motor() {
		// TODO Auto-generated constructor stub
	}

}
