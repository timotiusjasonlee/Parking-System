package Main;

 
public class RegisteredMember extends Employee {

	public RegisteredMember(String username, String password, String name, String id) {
		super(username, password, name, id);
		// TODO Auto-generated constructor stub
	}
	
}
