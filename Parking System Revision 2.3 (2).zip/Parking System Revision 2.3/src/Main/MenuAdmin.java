package Main;

import java.util.ArrayList;
import java.util.Random;

import ParkingSystem.MenuUtama;

public class MenuAdmin {

	static Random rand = new Random();
	static ArrayList<Employee> arrAdmin = new ArrayList<Employee>();
	static ArrayList<RegisteredMember> dataEmployee = new ArrayList<RegisteredMember>();

	Employee a;
	static int choose = 0, id, flag = 0, count = 0;

	String password1;
	String confirm;
	static String username;
	static String password;
	static String name;
	static String temp;

	static boolean flagWhite, flagLowerCase, flagUpperCase, flagNumber, flagCharacters;
	static boolean checkUser;
	static boolean idExists;

	public static void passwordValidate(String pass, int maxLength, int counter) {
		if (maxLength == counter) {
			if (flagCharacters == false) {
				System.out.println("[Password must contain at least one of these special characters '!', ''"
						+ "', '#','$', '%', '&', '(', '), '*', '+', ',', '-', '.']");
				return;
			} else if (flagUpperCase == false) {
				System.out.println("[Password must contain at least one upper-case letter]");
				return;
			} else if (flagLowerCase == false) {
				System.out.println("[Password must contain at least one lower-case letter]");
				return;
			} else if (flagNumber == false) {
				System.out.println("[Password must contain at least one numeric]");
				return;
			}
			return;
		} else {
			if (pass.charAt(counter) == '!' || pass.charAt(counter) == '"' || pass.charAt(counter) == '#'
					|| pass.charAt(counter) == '$' || pass.charAt(counter) == '%' || pass.charAt(counter) == '&'
					|| pass.charAt(counter) == '(' || pass.charAt(counter) == ')' || pass.charAt(counter) == '*'
					|| pass.charAt(counter) == '+' || pass.charAt(counter) == ',' || pass.charAt(counter) == '-'
					|| pass.charAt(counter) == '.') {
				flagCharacters = true;
			} else if (pass.charAt(counter) >= 'a' && pass.charAt(counter) <= 'z') {
				flagLowerCase = true;
			} else if (pass.charAt(counter) >= 'A' && pass.charAt(counter) <= 'Z') {
				flagUpperCase = true;
			} else if (pass.charAt(counter) >= '0' && pass.charAt(counter) <= '9') {
				flagNumber = true;
			} else if (pass.charAt(counter) == ' ') {
				flagWhite = true;
				System.out.println("[Password cannot contain any whitespace]");
				return;
			}

		}
		passwordValidate(pass, maxLength, counter + 1);

	}

	public static void userValidate(String user, int count) {
		if (count == user.length()) {
			return;
		} else {
			if (user.charAt(count) == ' ') {
				flagWhite = true;
				System.out.println("[Username cannot contains any whitespace]");
				return;
			}
		}
		userValidate(user, count + 1);
	}

	public MenuAdmin() {

		do {

			if (arrAdmin.isEmpty()) {
				System.out.println("New Admin");
				do {
					System.out.print("Input your name [2 - 36 Characters]    : ");
					name = Main.in.nextLine();

				} while (name.length() < 2 || name.length() > 36 || checkUser == true);

				nameConverter();

				do {
					checkUser = false;
					System.out.print("Input new Username [2 - 36 Characters] : ");
					username = Main.in.next();
					checkUser(name);
					Main.in.nextLine();

				} while (username.length() < 2 || username.length() > 36 || checkUser == true);

				do {
					flagWhite = false;
					flagLowerCase = false;
					flagUpperCase = false;
					flagNumber = false;
					flagCharacters = false;

					System.out.print("Input new Password                     : ");
					password = Main.in.next();
					Main.in.nextLine();
					passwordValidate(password, password.length(), 0);

				} while (flagCharacters == false || flagLowerCase == false || flagNumber == false
						|| flagUpperCase == false || flagWhite == true || password.length() < 8
						|| password.length() > 32);

				do {
					idExists = false;
					id = rand.nextInt(999) + 1 + 2000;
					temp = Integer.toString(id);
				} while (id > 2999 && id < 2000 && idExists == true);

				a = new RegisteredAdmin(username, password, name, temp);

				arrAdmin.add(a);

				System.out.println();
				System.out.println("New Admin Registered!");
				System.out.println("Name     : " + name);
				System.out.println("Username : " + username);
				System.out.println("Password : " + password);
				System.out.println("User ID  : " + temp);
				Main.username = username;
				Main.name = name;
				Main.in.nextLine();
				Main.clr();

			} else {

				System.out.println("Welcome to Parking Machine Admin app, " + Main.name);
				displaykedua();

				try {
					System.out.print("Choose>> ");
					choose = Main.in.nextInt();
					Main.in.nextLine();
				} catch (Exception e) {
					Main.in.nextLine();
				}

				switch (choose) {
				case 1:
					do {
						System.out.print("Input your name [2 - 36 Characters]    : ");
						name = Main.in.nextLine();

					} while (name.length() < 2 || name.length() > 36 || checkUser == true);

					nameConverter();

					do {

						checkUser = false;
						System.out.print("Input new Username [2 - 36 Characters] : ");
						username = Main.in.next();
						Main.in.nextLine();
						checkUser(username);

					} while (username.length() < 2 || username.length() > 36 || checkUser == true);

					do {
						flagWhite = false;
						flagLowerCase = false;
						flagUpperCase = false;
						flagNumber = false;
						flagCharacters = false;

						System.out.print("Input new Password                     : ");
						password = Main.in.next();
						Main.in.nextLine();
						passwordValidate(password, password.length(), 0);

					} while (flagCharacters == false || flagLowerCase == false || flagNumber == false
							|| flagUpperCase == false || flagWhite == true || password.length() < 8
							|| password.length() > 32);
					
					do {
						idExists = false;
						id = rand.nextInt(999) + 1 + 2000;
						temp = Integer.toString(id);
						checkID();
					} while (id > 2999 && id < 2000 && idExists == true);

					
					a = new RegisteredAdmin(username, password,name,temp);

					arrAdmin.add(a);
					System.out.println();
					System.out.println("New Admin Registered!");
					System.out.println("Name     : " + name);
					System.out.println("Username : " + username);
					System.out.println("Password : " + password);
					System.out.println("User ID  : " + temp);
					Main.in.nextLine();
					Main.clr();
					break;

				case 2:
					if (arrAdmin.isEmpty()) {
						System.out.println("[No Admin registered]");
					} else {
						new MenuEmployee();
					}
					break;
					
				case 3:
					System.out.println("============");
					System.out.println("Total Income");
					System.out.println("============");
					System.out.println("Total Income: "+MenuUtama.totalAcumulate);
					Main.in.nextLine();
				}
			}
			Main.clr();
		} while (choose != 4);
	}

	public static void checkID() {
		for (int i = 0; i < arrAdmin.size(); i++) {
			if (arrAdmin.get(i).getId().equals(temp))
				idExists = true;
			break;
		}
	}

	public static void nameConverter() {
		StringBuffer string1 = new StringBuffer();

		for (int i = 0; i < name.length(); i++) {
			if (i == 0)
				string1 = string1.append(name.toUpperCase().charAt(i));

			else {
				if (name.charAt(i - 1) == ' ')
					string1 = string1.append(name.toUpperCase().charAt(i));

				else if (name.charAt(i) != ' ')
					string1 = string1.append(name.charAt(i));
				else
					string1 = string1.append(" ");

			}
		}
		name = string1.toString();
	}

	private void printemployee() {
		System.out.println("____________________________________________");
		System.out.println("                  Admin Lists               |");
		System.out.println("____________________________________________");
		System.out.println(" Id. | Admin Username                       |");
		System.out.println("____________________________________________");
		for (Employee a : arrAdmin) {
			int parseInt = Integer.parseInt(a.getId());
			if (parseInt > 2000 && parseInt < 3000) {
				System.out.printf(" %-4s| %-37s|\n", a.getId(), a.getUsername());
			}
		}
		System.out.println("____________________________________________");

	}

	private void displaykedua() {
		System.out.println("======================");
		System.out.println("Admin's Menu");
		System.out.println("======================");
		System.out.println("1. Add Admin");
		System.out.println("2. Member Menu");
		System.out.println("3. View Income");
		System.out.println("4. Exit");
	}

	public static void checkUser(String Username) {
		for (int i = 0; i < arrAdmin.size(); i++) {
			if (arrAdmin.get(i).getUsername().equals(Username)) {
				System.out.println("[Username already Exist]");
				checkUser = true;
				break;
			}
		}
	}
	

}
