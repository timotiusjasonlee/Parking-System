package Main;

import java.util.ArrayList;
import java.util.Scanner;

import ParkingSystem.Kendaraan;
import ParkingSystem.MenuUtama;

import java.util.Collections;

public class Main {
	
	static int temp;
	
	public static Scanner in = new Scanner(System.in);
	public static int counterEntrace = 0;
	public static String username = "", password = "", name = "";
	public static ArrayList<Kendaraan> dataKendaraan = new ArrayList<Kendaraan>();	

	static public void clr() {

		for (int i = 0; i < 50; i++) {
			System.out.println();
		}
	}

	public static void main(String[] args) {
		do {

			System.out.print("Username/UserID: ");
			username = in.next();
			in.nextLine();

			System.out.print("Password       : ");
			password = in.next();
			in.nextLine();

			if (MenuAdmin.arrAdmin.isEmpty() && username.equals("admin") && password.equals("admin")) {
				clr();
				new MenuAdmin();

			} else {
				if (MenuAdmin.arrAdmin.isEmpty()) {
				}
				else {
					for (int i = 0; i < MenuAdmin.arrAdmin.size(); i++) {
						if ((username.equals(MenuAdmin.arrAdmin.get(i).getUsername()) || username.equals(MenuAdmin.arrAdmin.get(i).getId())) && password.equals(MenuAdmin.arrAdmin.get(i).getPassword())) {
		
							int parseInt = Integer.parseInt(MenuAdmin.arrAdmin.get(i).getId());
							if(parseInt >= 2001 && parseInt <=2999 ) {
								clr();
								username = MenuAdmin.arrAdmin.get(i).getUsername();
								name = MenuAdmin.arrAdmin.get(i).getName();
								new MenuAdmin();
								clr();
							
							}
							else
							{
								clr();
								new MenuUtama();
								clr();
							
							}
							
							break;
						} 
						else if(i == MenuAdmin.arrAdmin.size()-1 && (!username.equals(MenuAdmin.arrAdmin.get(i).getUsername()) || !username.equals(MenuAdmin.arrAdmin.get(i).getId())) && !password.equals(MenuAdmin.arrAdmin.get(i).getPassword())){
							System.out.println("[Incorrect username/id or password]");
							clr();
							break;
						}
					}
				}
			}
		} while (!username.equals("EXIT"));

	}
}
