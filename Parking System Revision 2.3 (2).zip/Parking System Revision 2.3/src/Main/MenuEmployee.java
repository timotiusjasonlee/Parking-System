package Main;

import java.util.Random;

public class MenuEmployee {

	public MenuEmployee() {
		int choose = 0;
		String confirm=null;
		String tempNama = null, tempID = null, tempPassword = null, tempUsername = null;
		Employee a;
		RegisteredMember registeredMember;

		do {
			Main.clr();
			System.out.println("=================");
			System.out.println("Member Menu");
			System.out.println("=================");
			System.out.println("1. Add Member");
			System.out.println("2. Remove Member");
			System.out.println("3. Promote Member");
			System.out.println("4. Exit");
			System.out.print("Choose>> ");
			try {
				choose = Main.in.nextInt();
				Main.in.nextLine();
			} catch (Exception e) {
				Main.in.nextLine();
			}
			switch (choose) {

			case 1:
				menuSatu();
				Main.in.nextLine();
				break;

			case 2:
				printemployee();
				menuDua();

				Main.in.nextLine();
				break;

			case 3:
				printemployee();
				a = new Employee(tempUsername, tempPassword, tempNama, tempID);
				menuTiga(confirm, tempNama, tempID, tempPassword, tempUsername,a);
				
				break;
			}

		} while (choose != 4);
	}

	public void menuDua() {
		if (MenuAdmin.dataEmployee.isEmpty() == false) {

			do {
				System.out.print("Input member username/userID to be remove : ");
				Main.username = Main.in.nextLine();
			} while (Main.username.length() == 0);

			for (int i = 0; i < MenuAdmin.arrAdmin.size(); i++) {

				if (Main.username.equals(MenuAdmin.arrAdmin.get(i).getUsername())
						|| Main.username.equals(MenuAdmin.arrAdmin.get(i).getId())) {

					for (int j = 0; j < MenuAdmin.dataEmployee.size(); j++) {
						if (Main.username.equals(MenuAdmin.dataEmployee.get(j).getUsername())
								|| Main.username.equals(MenuAdmin.dataEmployee.get(j).getId())) {

							MenuAdmin.dataEmployee.remove(j);
							break;
						}
					}

					MenuAdmin.arrAdmin.remove(i);
					System.out.println("[Member has been removed!]");
					break;
				}

				if (i == MenuAdmin.arrAdmin.size() - 1
						&& (!Main.username.equals(MenuAdmin.arrAdmin.get(i).getUsername())
								|| !Main.username.equals(MenuAdmin.arrAdmin.get(i).getId()))) {
					System.out.println("[No member found]");
					break;

				}
			}
		}
	}

	public void menuSatu() {
		Employee a;
		RegisteredMember registeredMember;
		do {
			System.out.print("Input your name [2 - 36 Characters]    : ");
			MenuAdmin.name = Main.in.nextLine();

		} while (MenuAdmin.name.length() < 2 || MenuAdmin.name.length() > 36 || MenuAdmin.checkUser == true);

		MenuAdmin.nameConverter();

		do {
			MenuAdmin.checkUser = false;
			MenuAdmin.flagWhite = false;
			System.out.print("Input new username [2 - 36 Characters] : ");
			MenuAdmin.username = Main.in.nextLine();
			MenuAdmin.checkUser(MenuAdmin.username);
			MenuAdmin.userValidate(MenuAdmin.username, 0);

		} while (MenuAdmin.checkUser == true || MenuAdmin.flagWhite == true || MenuAdmin.username.length() < 2
				|| MenuAdmin.username.length() > 36);

		do {
			MenuAdmin.flagWhite = false;
			MenuAdmin.flagLowerCase = false;
			MenuAdmin.flagUpperCase = false;
			MenuAdmin.flagNumber = false;
			MenuAdmin.flagCharacters = false;

			System.out.print("Input new password                     : ");
			MenuAdmin.password = Main.in.nextLine();
			MenuAdmin.passwordValidate(MenuAdmin.password, MenuAdmin.password.length(), 0);

		} while (MenuAdmin.flagCharacters == false || MenuAdmin.flagLowerCase == false
				|| MenuAdmin.flagNumber == false || MenuAdmin.flagUpperCase == false
				|| MenuAdmin.flagWhite == true || MenuAdmin.password.length() < 8
				|| MenuAdmin.password.length() > 32);

		do {
			MenuAdmin.idExists = false;
			MenuAdmin.id = MenuAdmin.rand.nextInt(999) + 1 + 3000;
			MenuAdmin.temp = Integer.toString(MenuAdmin.id);
			MenuAdmin.checkID();
		} while (MenuAdmin.id > 3999 && MenuAdmin.id < 3000 && MenuAdmin.idExists == true);

		a = new RegisteredMember(MenuAdmin.username, MenuAdmin.password, MenuAdmin.name, MenuAdmin.temp);
		registeredMember = new RegisteredMember(MenuAdmin.username, MenuAdmin.password, MenuAdmin.name,
				MenuAdmin.temp);

		MenuAdmin.arrAdmin.add(a);
		MenuAdmin.dataEmployee.add(registeredMember);

		System.out.println();
		System.out.println("New Member Registered!");
		System.out.println("Name     : " + MenuAdmin.name);
		System.out.println("Username : " + MenuAdmin.username);
		System.out.println("Password : " + MenuAdmin.password);
		System.out.println("User ID  : " + MenuAdmin.temp);
	}

	public void menuTiga(String confirm,String tempNama,String tempID, String tempPassword,String tempUsername, Employee a) {
		if (MenuAdmin.dataEmployee.isEmpty() == false) {
			do {
				System.out.print("PLease input member username/userID to be update : ");
				Main.username = Main.in.nextLine();
			} while (Main.username.length() == 0);

			for (int i = 0; i < MenuAdmin.arrAdmin.size(); i++) {
				if (Main.username.equals(MenuAdmin.arrAdmin.get(i).getUsername())
						|| Main.username.equals(MenuAdmin.arrAdmin.get(i).getId())) {

					do {
						System.out.print("are you sure want to promote "
								+ MenuAdmin.arrAdmin.get(i).getUsername() + " [yes | no] ");
						confirm = Main.in.nextLine();
					} while (!confirm.equals("yes") && !confirm.equals("no"));

					if (confirm.equals("yes")) {

						do {
							MenuAdmin.idExists = false;
							MenuAdmin.id = MenuAdmin.rand.nextInt(999) + 1 + 2000;
							MenuAdmin.temp = Integer.toString(MenuAdmin.id);
							MenuAdmin.checkID();
						} while (MenuAdmin.id > 2999 && MenuAdmin.id < 2000 && MenuAdmin.idExists == true);

						for (int j = 0; j < MenuAdmin.dataEmployee.size(); j++) {
							if (Main.username.equals(MenuAdmin.dataEmployee.get(j).getUsername())
									|| Main.username.equals(MenuAdmin.dataEmployee.get(j).getId())) {
								tempNama = MenuAdmin.dataEmployee.get(j).getName();
								tempID = MenuAdmin.temp;
								tempPassword = MenuAdmin.dataEmployee.get(j).getPassword();
								tempUsername = MenuAdmin.dataEmployee.get(j).getUsername();

								MenuAdmin.dataEmployee.remove(j);
								break;
							}
							
						}

						a = new Employee(tempUsername, tempPassword, tempNama, tempID);

						MenuAdmin.arrAdmin.set(i, a);

						System.out.println();
						System.out.println("Member has been promoted");
						System.out.println("Name     : " + tempNama);
						System.out.println("Username : " + tempUsername);
						System.out.println("Password : " + tempPassword);
						System.out.println("User ID  : " + tempID);
						Main.in.nextLine();
						break;

					} else {
						Main.clr();
						printemployee();
						menuTiga(confirm, tempNama, tempID, tempPassword, tempUsername, a);
						break;
					}
				}
				if (i == MenuAdmin.arrAdmin.size() - 1
						&& (!Main.username.equals(MenuAdmin.arrAdmin.get(i).getUsername())
								|| !Main.username.equals(MenuAdmin.arrAdmin.get(i).getId()))) {
					System.out.println("[No member found]");
					Main.in.nextLine();
					break;

				}
			}
		} 
		else {
			Main.in.nextLine();
		}
	}
	private void printemployee() {
		if (MenuAdmin.dataEmployee.isEmpty()) {

			System.out.println(" ____________________________________________");
			System.out.println("|                 Employe Lists              |");
			System.out.println("|____________________________________________|");
			System.out.println("| Id. |         Employee Username            |");
			System.out.println("|     |             No Data                  |");
			System.out.println(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
		} else {
			System.out.println(" ____________________________________________");
			System.out.println("|                Employee Lists              |");
			System.out.println("|____________________________________________|");
			System.out.println("| Id. |         Employee Username            |");
			System.out.println("|_____|______________________________________|");
			for (Employee registeredMember : MenuAdmin.dataEmployee) {
				int parseInt = Integer.parseInt(registeredMember.getId());
				if (parseInt > 3000 && parseInt < 3999) {
					System.out.printf("| %-4s| %-37s|\n", registeredMember.getId(), registeredMember.getUsername());
				}

			}
			System.out.println(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
		}

	}

}
